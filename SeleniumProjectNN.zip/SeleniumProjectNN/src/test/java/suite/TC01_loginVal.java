package suite;

import org.testng.annotations.Test;

import base.Common;
import pages.LoginPage;

public class TC01_loginVal extends Common {

	@Test
	void loginVal() throws InterruptedException {
		LoginPage lp = new LoginPage(d);
		lp.login();
	}

}
