package pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import base.Common;

public class LoginPage extends Common {

	public LoginPage(WebDriver d) {
		PageFactory.initElements(d, this);
	}

	@FindBy(name = "username")
	WebElement un;

	@FindBy(name = "password")
	WebElement pa;

	@FindBy(xpath = "//*[@type='submit']")
	WebElement submit;

	public void login() throws InterruptedException {

		Thread.sleep(3000);
		un.sendKeys("Admin");
		pa.sendKeys("admin123");
		submit.click();
	}

}
